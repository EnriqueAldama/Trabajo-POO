/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Screens;

import Manager.SimpleKiosk;
import Manager.TranslatorManager;

/**
 *
 * @author Alfa
 */
public class IdiomScreen implements KioskScreen {

    public IdiomScreen() {
    }
    
}
