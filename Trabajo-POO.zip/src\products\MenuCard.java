/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package products;

import products.MenuCardSection;
import java.util.List;

/**
 *
 * @author am.machuca.2023
 */
public class MenuCard {
    private List<MenuCardSection> sectionList;
    
    public Section getSection(int c){
        
    }
    
    public int getNumberOfSections(){
        
    }
    
    public static MenuCard loadFromDisk(){
        
    }

    public MenuCard(List<MenuCardSection> sectionList) {
        this.sectionList = sectionList;
    }
}
